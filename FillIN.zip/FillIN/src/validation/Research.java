package validation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connect.myConnection;

public class Research {
	Connection con;
	Statement st;
	ResultSet rs;

	public Research() {
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertContent(String dissid, String userid, String rContent,
			String rDate, String rTime) {
		try {
			st.executeUpdate("insert into research(dissid, userid, RDate, RTime, researchCol) values('"
					+ dissid
					+ "', '"
					+ userid
					+ "', '"
					+ rDate
					+ "', '"
					+ rTime
					+ "', researchTable(researchObject('"
					+ rContent
					+ "')))");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateContent(String dissid, String userid, String rContent) {
		try {
			st.executeUpdate("update table(select researchcol from research where dissID = '"
					+ dissid
					+ "' and userid = '"
					+ userid
					+ "') set rcontent = '" + rContent + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteContent(String dissid, String userid) {
		try {
			st.executeUpdate("delete table(select researchCol from research where dissID = '"
					+ dissid + "', userid = '" + userid + "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getUserLastContent(String dissid, String userid) {
		String rContent = "";
		try {
			rs = st.executeQuery("select D.Rcontent from research, table(research.researchCol)D where dissID = '"
					+ dissid
					+ "' and userID = '"
					+ userid
					+ "' order by rdate, rtime DESC");
			while (rs.next()) {
				rContent = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rContent;
	}

	public ArrayList<String> getUserContent(String dissid, String userid) {
		ArrayList<String> rContent = new ArrayList<String>();
		try {
			rs = st.executeQuery("select D.Rcontent from research, table(research.researchCol)D where dissID = '"
					+ dissid + "' and userid = '" + userid + "'");
			while (rs.next()) {
				rContent.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rContent;
	}
	
	protected void finalize(){
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
