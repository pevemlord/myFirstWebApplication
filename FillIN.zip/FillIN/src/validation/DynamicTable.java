package validation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connect.myConnection;

public class DynamicTable {
	Connection con;
	Statement st;
	ResultSet rs;
	public String dTable;
	

	public DynamicTable() {
		dTable = "";
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertData(String dTable, String username, String comment,
			String comDate, String comTime) {
		this.dTable = dTable;
		try {
			st.executeUpdate("insert into " + dTable
					+ "(user_name, user_comment, comDate, comTime) values('"
					+ username + "', '" + comment + "', '" + comDate + "', '"
					+ comTime + "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getUserLastComment(String dissid, String username) {
		String lcomment = "";
		dTable = dissid;
		try {
			rs = st.executeQuery("select user_comment from " + dTable
					+ " where user_name = '" + username
					+ "' Order by comDate, comTime DESC");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lcomment;
	}

	public ArrayList<String> getUserAllComment(String dissid, String username) {
		ArrayList<String> gComment = new ArrayList<String>();
		dTable = dissid;
		try {
			rs = st.executeQuery("select user_comment from " + dTable
					+ " where user_name = '" + username + "'");
			while (rs.next()) {
				gComment.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return gComment;
	}

	public ArrayList<String> getAllComment(String dissid) {
		ArrayList<String> aComment = new ArrayList<String>();
		dTable = dissid;
		try {
			rs = st.executeQuery("select user_comment from " + dTable);
			while (rs.next()) {
				aComment.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return aComment;
	}
	
	public String getLastComment(String dissid){
		String comment = "";
		try {
			rs = st.executeQuery("select comment from " + dissid + " where rownum < 2 order by comDate, comTime DESC");
			if(rs.next()){
				comment = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return comment;
	}

	protected void finalize() {
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
