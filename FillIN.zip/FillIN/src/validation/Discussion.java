package validation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connect.myConnection;

public class Discussion {
	Connection con;
	Statement st;
	ResultSet rs;

	public Discussion() {
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertRecord(String dissid, String topic, String startDate,
			String startTime, String Duration) {
		try {
			st.executeUpdate("insert into discussion(diss_id, diss_topic, diss_description, diss_started_date, diss_started_time, diss_duration, participant_list) values('"
					+ dissid
					+ "', '"
					+ topic
					+ "',  (select diss_description from invitation where diss_id = '"
					+ dissid
					+ "'), '"
					+ startDate
					+ "', '"
					+ startTime
					+ "','"
					+ Duration
					+ "', participant(involver((select created_by from invitation where diss_id = '"
					+ dissid + "'))))");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertRecord(String dissid) {
		try {
			st.executeQuery("insert into discussion(diss_id, diss_topic, diss_description, diss_started_date, diss_started_time,participant_list) values('"
					+ dissid
					+ "',  (select diss_topic from invitation where diss_id = '"
					+ dissid
					+ "'),"
					+ "(select diss_description from invitation where diss_id = '"
					+ dissid
					+ "'),"
					+ "(select diss_date from invitation where diss_id = '"
					+ dissid
					+ "'),"
					+ "(select diss_time from invitation where diss_id = '"
					+ dissid
					+ "'),"
					+ "participant(involver((select I.user_id from invitation, table(invitation.participant_list)I where diss_ID = '"
					+ dissid
					+ "' and rownum = 1), (select I.userrole from invitation, table(invitation.participant_list)I where diss_ID = '"
					+ dissid + "' and rownum < 2))))");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void addParticipant(String dissid, String participant, String role) {
		try {
			st.executeUpdate("insert into table(select participant_list from discussion where diss_id = '"
					+ dissid
					+ "') values('"
					+ participant
					+ "', '"
					+ role
					+ "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteParticipant(String dissid, String participant) {
		try {
			st.executeUpdate("delete table(select participant_list from discussion where diss_id = '"
					+ dissid + "') where user_id = '" + participant + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateRecord(String dissid, String endDate, String endTime) {
		try {
			st.executeUpdate("update Discussion set diss_end_date = '"
					+ endDate + "', diss_end_time = '" + endTime
					+ "', where diss_id ='" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateRecord(String dissid, String endDate, String endTime,
			String Conculsion) {
		try {
			st.executeUpdate("update Discussion set diss_end_date = '"
					+ endDate + "', diss_end_time = '" + endTime
					+ "', Conculsion = '" + Conculsion + "' where diss_id ='"
					+ dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateConculsion(String dissid, String Conculsion) {
		try {
			st.executeUpdate("update Discussion set Conculsion = '"
					+ Conculsion + "' where diss_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateDuration(String dissid, String duration) {
		try {
			st.executeUpdate("update Discussion set diss_duration = '"
					+ duration + "' where diss_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateParticipantRole(String dissid, String participantName,
			String newRole) {
		try {
			st.executeUpdate("update table(select participant_list from Discussion where diss_id = '"
					+ dissid
					+ "') set role = '"
					+ newRole
					+ "' where user_id = '" + participantName + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String viewTopic(String dissid) {
		String topic = "";
		try {
			rs = st.executeQuery("select diss_topic from Discussion where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				topic = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return topic;
	}

	public String viewStartDate(String dissid) {
		String startDate = "";
		try {
			rs = st.executeQuery("select diss_started_date from Discussion where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				startDate = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return startDate;
	}

	public String viewStartTime(String dissid) {
		String StartTime = "";
		try {
			rs = st.executeQuery("select diss_started_time from Discussion where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				StartTime = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return StartTime;
	}

	public String viewEndDate(String dissid) {
		String endDate = "";
		try {
			rs = st.executeQuery("select diss_end_date from Discussion where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				endDate = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return endDate;
	}

	public String viewEndTime(String dissid) {
		String endTime = "";
		try {
			rs = st.executeQuery("select diss_end_time from Discussion where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				endTime = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return endTime;
	}

	public String viewConculsion(String dissid) {
		String Conculsion = "";
		try {
			rs = st.executeQuery("select Conculsion from Discussion where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				Conculsion = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Conculsion;
	}

	public ArrayList<String> viewParticipantList(String dissid) {
		ArrayList<String> participantlist = new ArrayList<String>();
		try {
			rs = st.executeQuery("select T.userlist from Discussion, table(Discussion.participant_list) where diss_id ='"
					+ dissid + "'");
			while (rs.next()) {
				participantlist.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return participantlist;
	}

	public String getDuration(String dissid) {
		String duration = "";
		try {
			rs = st.executeQuery("select diss_duration from Discussion where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				duration = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return duration;
	}

	protected void finalize() {
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}