package validation;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import connect.myConnection;

public class user {
	Connection con;
	Statement st;
	ResultSet rs;

	public user() {
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	};

	public boolean checkingUser(String username, String password) {
		boolean flag = false;
		try {
			rs = st.executeQuery("select count(*) from loginData where user_id = '"
					+ username + "' and user_pass = '" + password + "'");
			if (rs.next()) {
				flag = rs.getInt(1) == 1 ? true : false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean checkingUser(String username) {
		boolean flag = false;
		try {
			rs = st.executeQuery("select count(*) from loginData where user_id = '"
					+ username + "'");
			if (rs.next()) {
				flag = rs.getInt(1) == 1 ? true : false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public void addUser(String username, String password, String name,
		String email, String dOB, String sex, String country) {
		Statement st1 = null, st2 = null;
		try {
			st1 = con.createStatement();
			st2 = con.createStatement();
			st1.executeUpdate("insert into userAccount(user_id, user_name, user_email, date_of_birth, user_sex, user_country, user_phone) values('"
					+ username
					+ "', '"
					+ name
					+ "', '"
					+ email
					+ "', '"
					+ dOB
					+ "', '" + sex + "', '" + country + "', ' 8860396602 ')");
			st.executeUpdate("insert into loginData(user_id, user_pass) values('"
					+ username + "', '" + password + "')");
			st2.executeUpdate("insert into userfriendsList(username, friends_list) values('"
					+ username + "', friendsTable(friend(NULL)))");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				st1.close();
				st2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void addUser(String username, String password, String name,
			String email, String dOB, String sex) {
			Statement st1 = null, st2 = null;
			try {
				st1 = con.createStatement();
				st2 = con.createStatement();
				st1.executeUpdate("insert into userAccount(user_id, user_name, user_email, date_of_birth, user_sex) values('"
						+ username
						+ "', '"
						+ name
						+ "', '"
						+ email
						+ "', '"
						+ dOB
						+ "', '" + sex + "')");
				st.executeUpdate("insert into loginData(user_id, user_pass) values('"
						+ username + "', '" + password + "')");
				st2.executeUpdate("insert into userfriendsList(username, friends_list) values('"
						+ username + "', friendsTable(friend(NULL)))");
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					st1.close();
					st2.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	public void upDatePass(String username, String password) {
		try {
			st.executeUpdate("update loginData set user_pass = '" + password
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateName(String username, String Name) {
		try {
			st.executeUpdate("update userAccount set user_name = '" + Name
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateEmail(String username, String Email) {
		try {
			st.executeUpdate("update userAccount set user_email = '" + Email
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateBirth(String username, String bDate) {
		try {
			st.executeUpdate("update userAccount set date_of_birth = '" + bDate
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDatePhone(String username, String phone) {
		try {
			st.executeUpdate("update userAccount set user_phone = '" + phone
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateCountry(String username, String country) {
		try {
			st.executeUpdate("update userAccount set user_country = '"
					+ country + "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateSex(String username, String sex) {
		try {
			st.executeUpdate("update userAccount set user_sex = '" + sex
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateState(String username, String state) {
		try {
			st.executeUpdate("update userAccount set user_state = '" + state
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateCity(String username, String city) {
		try {
			st.executeUpdate("update userAccount set user_city = '" + city
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void upDateZipCode(String username, double zipcode) {
		try {
			st.executeUpdate("update userAccount set zipcode = '" + zipcode
					+ "' where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteAccount(String username) {
		try {
			st.executeUpdate("delete from userAccount where user_id = '"
					+ username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getName(String username) {
		String Name = "";
		try {
			rs = st.executeQuery("select user_name from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				Name = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Name;
	}

	public String getEmail(String username) {
		String Email = "";
		try {
			rs = st.executeQuery("select user_email from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				Email = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Email;
	}

	public String getBirthDate(String username) {
		String Bdate = "";
		try {
			rs = st.executeQuery("select date_of_birth from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				Bdate = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Bdate;
	}

	public String getPhone(String username) {
		String Phone = "";
		try {
			rs = st.executeQuery("select user_phone from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				Phone = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Phone;
	}

	public String getSex(String username) {
		String Sex = "";
		try {
			rs = st.executeQuery("select user_sex from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				Sex = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Sex;
	}

	public String getCountry(String username) {
		String Country = "";
		try {
			rs = st.executeQuery("select user_country from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				Country = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Country;
	}

	public String getState(String username) {
		String State = "";
		try {
			rs = st.executeQuery("select user_state from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				State = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return State;
	}

	public String getCity(String username) {
		String City = "";
		try {
			rs = st.executeQuery("select user_city from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				City = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return City;
	}

	public BigDecimal getZipCode(String username) {
		BigDecimal Zipcode = null;
		try {
			rs = st.executeQuery("select zipcode from userAccount where user_id = '"
					+ username + "'");
			if (rs.next())
				Zipcode = rs.getBigDecimal(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Zipcode;
	}
}
