package validation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connect.myConnection;

public class Invitation {
	Connection con;
	Statement st;
	ResultSet rs;
	public String DISSID;

	public Invitation() {
		DISSID = "";
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getDissID(){
		return DISSID;
	}
	
	public void insertData(String createdBy, String dissTopic, String dissDescription, String type, String purpose,
			String dissDate, String dissTime, String Duration) {
		Statement st1;
		try {
			st1 = con.createStatement();
			st.executeQuery("insert into invitation(diss_id, created_by, diss_topic, diss_description, diss_type, diss_purpose, diss_date, diss_time, diss_duration, participant_list) values("
					+ "'DIS'||dissCounter.nextval"
					+ ", '"
					+ createdBy
					+ "', '"
					+ dissTopic
					+ "', '"
					+ dissDescription
					+ "', '"
					+ type
					+ "', '"
					+ purpose
					+ "', '"
					+ dissDate
					+ "', '"
					+ dissTime
					+ "', '"
					+ Duration
					+ "', participant(involver('" + createdBy + "', 'admin')))");
			rs = st1.executeQuery("select diss_id from invitation where rownum = 1 order by diss_id DESC");
			if(rs.next()){
				DISSID = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void addParticipant(String participant, String role) {
		try {
			st.executeQuery("insert into table(select participant_list from invitation where diss_id = '"
					+ DISSID + "') values(involver('" + participant + "', '" + role + "'))");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void addParticipant(String participant, String role, String dissid) {
		try {
			st.executeQuery("insert into table(select participant_list from invitation where diss_id = '"
					+ dissid + "') values(involver('" + participant + "', '" + role + "'))");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteParticipant(String username) {
		try {
			st.executeQuery("delete table(select participant_list from invitation where diss_id = '"
					+ DISSID + "') where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteParticipant(String username, String dissid) {
		try {
			st.executeQuery("delete table(select participant_list from invitation where diss_id = '"
					+ dissid + "') where user_id = '" + username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void changeTopic(String topic) {
		try {
			st.executeUpdate("update invitation set diss_topic = '" + topic
					+ "' where diss_id = '" + DISSID + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeTopic(String topic, String dissid) {
		try {
			st.executeUpdate("update invitation set diss_topic = '" + topic
					+ "' where diss_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeDescription(String desc){
		try {
			st.executeUpdate("update invitation set diss_description = '" + desc + "' where diss_id = '" + DISSID + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeDescription(String desc, String dissid){
		try {
			st.executeUpdate("update invitation set diss_description = '" + desc + "' where diss_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeType(String type){
		try {
			st.executeUpdate("update invitation set diss_type = '" + type + "' where diss_id = '" + DISSID + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeType(String type, String dissid){
		try {
			st.executeUpdate("update invitation set diss_type = '" + type + "' where diss_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changePurpose(String purpose){
		try {
			st.executeUpdate("update invitation set diss_purpose = '" + purpose + "' where diss_id = '" + DISSID + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changePurpose(String purpose, String dissid){
		try {
			st.executeUpdate("update invitation set diss_purpose = '" + purpose + "' where diss_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void changeDate(String Ddate) {
		try {
			st.executeUpdate("update invitation set diss_date = '" + Ddate
					+ "' where user_id = '" + DISSID + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeDate(String Ddate, String dissid) {
		try {
			st.executeUpdate("update invitation set diss_date = '" + Ddate
					+ "' where user_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void changeTime(String Dtime) {
		try {
			st.executeUpdate("update invitation set diss_time = '" + Dtime
					+ "' where user_id = '" + DISSID + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeTime(String Dtime, String dissid) {
		try {
			st.executeUpdate("update invitation set diss_time = '" + Dtime
					+ "' where user_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void changeDuration(String Duration){
		try {
			st.executeUpdate("update invitation set diss_duration = '" + Duration + "' where diss_id = '" + DISSID + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void changeDuration(String Duration, String dissid){
		try {
			st.executeUpdate("update invitation set diss_duration = '" + Duration + "' where diss_id = '" + dissid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteDiss(String dissid) {
		try {
			st.executeUpdate("delete invitation where diss_id ='" + dissid
					+ "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteDiss() {
		try {
			st.executeUpdate("delete invitation where diss_id ='" + DISSID
					+ "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getTopic(String dissid) {
		String topic = "";
		try {
			rs = st.executeQuery("select diss_topic from invitation where diss_id = '"
					+ dissid + "'");
			if (rs.next())
				topic = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return topic;
	}
	
	public String getTopic() {
		String topic = "";
		try {
			rs = st.executeQuery("select diss_topic from invitation where diss_id = '"
					+ DISSID + "'");
			if (rs.next())
				topic = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return topic;
	}
	
	public String getDescription(String dissid){
		String desc = "";
		try {
			rs = st.executeQuery("select diss_description from invitation where diss_id = '" + dissid + "'");
			if(rs.next()){
				desc = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return desc;
	}
	
	public String getDescription(){
		String desc = "";
		try {
			rs = st.executeQuery("select diss_description from invitation where diss_id = '" + DISSID + "'");
			if(rs.next()){
				desc = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return desc;
	}
	
	public String getType(String dissid){
		String type = "";
		try {
			rs = st.executeQuery("select diss_type from invitation where diss_id = '" + dissid + "'");
			if(rs.next()){
				type = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return type;
	}
	
	public String getType(){
		String type = "";
		try {
			rs = st.executeQuery("select diss_type from invitation where diss_id = '" + DISSID + "'");
			if(rs.next()){
				type = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return type;
	}
	
	public String getPurpose(String dissid){
		String purpose = "";
		try {
			rs = st.executeQuery("select diss_purpose from invitation where diss_id = '" + dissid + "'");
			if(rs.next()){
				purpose = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return purpose;
	}
	
	public String getPurpose(){
		String purpose = "";
		try {
			rs = st.executeQuery("select diss_purpose from invitation where diss_id = '" + DISSID + "'");
			if(rs.next()){
				purpose = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return purpose;
	}

	public String getCreatedBy(String dissid) {
		String createdBy = "";
		try {
			rs = st.executeQuery("select created_by from invitation where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				createdBy = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return createdBy;
	}
	
	public String getCreatedBy() {
		String createdBy = "";
		try {
			rs = st.executeQuery("select created_by from invitation where diss_id = '"
					+ DISSID + "'");
			if (rs.next()) {
				createdBy = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return createdBy;
	}

	public ArrayList<String> getInviteeList(String dissid) {
		ArrayList<String> invitees = new ArrayList<String>();
		try {
			rs = st.executeQuery("select I.user_id from invitation, table(invitation.participant_list)I where diss_ID = '"
					+ dissid + "'");
			while (rs.next()) {
				invitees.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return invitees;
	}
	
	public ArrayList<String> getInviteeList() {
		ArrayList<String> invitees = new ArrayList<String>();
		try {
			rs = st.executeQuery("select I.user_id from invitation, table(invitation.participant_list)I where diss_ID = '"
					+ DISSID + "'");
			while (rs.next()) {
				invitees.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return invitees;
	}

	public String getDate(String dissid) {
		String gDate = "";
		try {
			rs = st.executeQuery("select diss_date from invitation where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				gDate = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return gDate;
	}
	
	public String getDate() {
		String gDate = "";
		try {
			rs = st.executeQuery("select diss_date from invitation where diss_id = '"
					+ DISSID + "'");
			if (rs.next()) {
				gDate = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return gDate;
	}

	public String getTime(String dissid) {
		String gTime = "";
		try {
			rs = st.executeQuery("select diss_time from invitation where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				gTime = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return gTime;
	}
	
	public String getTime() {
		String gTime = "";
		try {
			rs = st.executeQuery("select diss_time from invitation where diss_id = '"
					+ DISSID + "'");
			if (rs.next()) {
				gTime = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return gTime;
	}

	public String getDuration(String dissid) {
		String duration = "";
		try {
			rs = st.executeQuery("select diss_duration from invitation where diss_id = '"
					+ dissid + "'");
			if (rs.next()) {
				duration = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return duration;
	}
	
	public String getDuration() {
		String duration = "";
		try {
			rs = st.executeQuery("select diss_duration from invitation where diss_id = '"
					+ DISSID + "'");
			if (rs.next()) {
				duration = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return duration;
	}

	protected void finalize() {
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}