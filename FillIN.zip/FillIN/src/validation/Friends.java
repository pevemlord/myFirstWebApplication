package validation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connect.myConnection;

public class Friends {
	Connection con;
	Statement st;
	ResultSet rs;

	public Friends() {
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public boolean checkingFriend(String userid) {
		boolean flag = false;
		try {
			rs = st.executeQuery("select count(*) from loginData where user_id = '"
					+ userid + "'");
			if (rs.next()) {
				flag = rs.getInt(1) == 1 ? true : false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public ArrayList<String> getFriendsList(String userid) {
		ArrayList<String> flist = new ArrayList<String>();
		try {
			rs = st.executeQuery("select F.* from userFriendsList, table(userFriendsList.friends_list)F where username = '"
					+ userid + "'");
			while (rs.next()) {
				flist.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flist;
	}

	public void insertFriend(String userid, String friend) {
		try {
			st.executeUpdate("delete table(select friends_list from userFriendsList where username = '"
					+ userid + "') where user_id = NULL");
			st.executeUpdate("insert into table(select friends_list from userFriendsList where username = '"
					+ userid + "') values('" + friend + "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteFriend(String userid, String friend) {
		try {
			st.executeUpdate("delete table(select friends_list from userFriendsList where username = '"
					+ userid + "') where user_id = '" + friend + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void finalize() {
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}