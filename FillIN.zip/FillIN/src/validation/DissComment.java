package validation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connect.myConnection;

class DissCommment {
	Connection con;
	Statement st;
	ResultSet rs;

	DissCommment() {
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertComment(String dissid, String userid, String comment,
			String dDate, String dTime) {
		try {
			st.executeUpdate("insert into Diss_Comment(diss_id, user_id, dComment, dDate, dTime) values('"
					+ dissid
					+ "','"
					+ userid
					+ "', '"
					+ comment
					+ "', '"
					+ dDate + "', '" + dTime + "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteComment(String dissid, String userid) {
		try {
			st.executeUpdate("delete from Diss_Comment where diss_id='"
					+ dissid + "' and user_id = '" + userid + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String viewUserComment(String dissid, String userid, String dDate,
			String dTime) {
		String comment = "";
		try {
			rs = st.executeQuery("select dComment from Diss_Comment where diss_id = '"
					+ dissid
					+ "' and user_id = '"
					+ userid
					+ "' and dDate ='"
					+ dDate + "' and dTime='" + dTime + "'");
			if (rs.next()) {
				comment = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return comment;
	}

	public ArrayList<String> viewAllUserComment(String dissid, String userid) {
		ArrayList<String> comment = new ArrayList<String>();
		try {
			rs = st.executeQuery("select dComment from Diss_Comment where diss_id = '"
					+ dissid + "' order by dDate, dTime DESC");
			while (rs.next()) {
				comment.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return comment;
	}

	public ArrayList<String> viewAllComment(String dissid) {
		ArrayList<String> vComm = new ArrayList<String>();
		try {
			rs = st.executeQuery("select dComment from Diss_Comment where diss_id = '"
					+ dissid + "'");
			while (rs.next()) {
				vComm.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vComm;
	}

	public String viewLastDate(String dissid, String username) {
		String dDate = "";
		try {
			rs = st.executeQuery("select dDate from Diss_comment where diss_id = '"
					+ dissid
					+ "' and user_id = '"
					+ username
					+ "' order by dDate DESC");
			if (rs.next()) {
				dDate = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dDate;
	}

	public ArrayList<String> viewAllDate(String dissid, String username) {
		ArrayList<String> dDate = new ArrayList<String>();
		try {
			rs = st.executeQuery("select dDate from Diss_comment where diss_id = '"
					+ dissid
					+ "' and user_id = '"
					+ username
					+ "' order by dDate DESC");
			while (rs.next()) {
				dDate.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dDate;
	}

	public String viewLastTime(String dissid, String username) {
		String dTime = "";
		try {
			rs = st.executeQuery("select dTime from Diss_comment where diss_id = '"
					+ dissid
					+ "' and user_id = '"
					+ username
					+ "' order by dDate DESC");
			if (rs.next()) {
				dTime = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dTime;
	}

	public ArrayList<String> viewAllTime(String dissid, String username) {
		ArrayList<String> dTime = new ArrayList<String>();
		try {
			rs = st.executeQuery("select dTime from Diss_comment where diss_id = '"
					+ dissid
					+ "' and user_id = '"
					+ username
					+ "' order by dDate DESC");
			while (rs.next()) {
				dTime.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dTime;
	}

	protected void finalize() {
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}