package validation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connect.myConnection;

class DisLikers {
	Connection con;
	Statement st;
	ResultSet rs;

	public DisLikers() {
		con = myConnection.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int viewlikeCounter(String dissid) {
		int counter = 0;
		try {
			rs = st.executeQuery("select count(user_id) from Diss_likers where diss_id = '"
					+ dissid + "'");
			while (rs.next()) {
				counter = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return counter;
	}

	public void addLike(String dissid, String username) {
		try {
			st.executeUpdate("insert into Diss_likers(diss_id, liker_list) values( '"
					+ dissid + "', '" + username + "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteLiker(String dissid, String username) {
		try {
			st.executeUpdate("delete from Diss_likers where diss_id = '"
					+ username + "'");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<String> viewLikers(String dissid) {
		ArrayList<String> vlike = new ArrayList<String>();
		try {
			rs = st.executeQuery("select user_id from Diss_likers where diss_id = '"
					+ dissid + "'");
			while (rs.next()) {
				vlike.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vlike;
	}

	public ArrayList<String> viewDiscussion(String username) {
		ArrayList<String> dlike = new ArrayList<String>();
		try {
			rs = st.executeQuery("select diss_id from Diss_likers where user_id = '"
					+ username + "'");
			while (rs.next()) {
				dlike.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dlike;
	}

	protected void finalize() {
		try {
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}