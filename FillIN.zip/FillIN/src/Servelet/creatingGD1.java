package Servelet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import validation.Invitation;

@WebServlet("/creatingGD")
public class creatingGD1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public creatingGD1() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Invitation inv = new Invitation();		
		
		//ADD SESSIONS OR COOKIE TO GET THE USERNAME
		
		Cookie[] s = request.getCookies();
		
		
		String TYPE = request.getAttribute("GDType").toString();
		String PURPOSE = request.getAttribute("GDPurpose").toString();
		String TOPIC = request.getAttribute("Topic").toString();
		String DESCRIPTION = request.getAttribute("Decription").toString();
		String GDDATE = request.getAttribute("GDDate").toString();
		String GDTIME = request.getAttribute("GDTime").toString();
		String GDDURATION = request.getAttribute("GDDuration").toString();
		String RESEARCHCONTENT = request.getAttribute("ResearchContent").toString();
		
		inv.insertData("pawanatri", TOPIC, DESCRIPTION, TYPE, PURPOSE, GDDATE, GDTIME, GDDURATION);
		
	}
}
