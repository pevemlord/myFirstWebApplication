package Servelet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import validation.user;

@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Registration() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		user uAC = new user();
		String uName = request.getAttribute("username").toString();
		String uPass = request.getAttribute("password").toString();
		String uEmail = request.getAttribute("emailID").toString();
		String name = request.getAttribute("Name").toString();
		String dateOfBirth = request.getAttribute("DOB").toString();
		String gender = request.getAttribute("Gender").toString();
		uAC.addUser(uName, uPass, name, uEmail, dateOfBirth, gender);
	}
}
